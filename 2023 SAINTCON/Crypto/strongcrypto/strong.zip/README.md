Recover the message, save the world.
